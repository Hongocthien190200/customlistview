package com.example.myfirstapp.Model;

import java.io.Serializable;

public class UserLoginDetailModel implements Serializable {
    private String userName;
    private String password;
    private String adress;

    public UserLoginDetailModel(String userName,String password,String adress){
        this.userName =userName;
        this.password = password;
        this.adress = adress;
    }
    public String getUserName() {
        return userName;
    }

    public void setUsername(String username) {
        this.userName = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getAdress() {
        return adress;
    }

    public void setAdress(String email) {
        this.adress = adress;
    }
}
