package com.example.myfirstapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import com.example.myfirstapp.Model.ContactModel;

import java.util.ArrayList;
import java.util.List;

public class ContactActivity extends AppCompatActivity {
    ListView listView;
    public static List<ContactModel> modelList;
    static ContactAdapter adapter;
    Button btnAddItem;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);
        onInit();
        onSetData();

        adapter = new ContactAdapter(ContactActivity.this, R.layout.contact_item,modelList);
        listView.setAdapter(adapter);

        btnAddItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ContactActivity.this,EditContactActivity.class);
                startActivity(intent);
            }
        });
    }
    private void onSetData(){
        modelList = new ArrayList();
        modelList.add(new ContactModel(0,"Jonh" ,"03344061783","Tp.HCM"));
        modelList.add(new ContactModel(1,"Hayva","03344061783","Tp.HANOI"));
        modelList.add(new ContactModel(2,"Neeu" ,"03344061783","Tp.DANANG"));
        modelList.add(new ContactModel(3,"Katan","03344061783","Tp.HUE"));
        modelList.add(new ContactModel(4,"Mucan","03344061783","Tp.NHATRANG"));
        modelList.add(new ContactModel(5,"Henry","03344061783","Tp.QUANGBINH"));
        modelList.add(new ContactModel(6,"Chi"  ,"03344061783","Tp.BIENHOA"));
        modelList.add(new ContactModel(7,"Jayc" ,"03344061783","Tp.HALONG"));

    }
    private void onInit(){
        listView = findViewById(R.id.lv_Contact);
        btnAddItem = findViewById(R.id.contact_btnAdd);
    }
}
