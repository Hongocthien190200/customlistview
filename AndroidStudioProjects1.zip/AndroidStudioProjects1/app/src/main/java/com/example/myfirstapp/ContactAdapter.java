package com.example.myfirstapp;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myfirstapp.Model.ContactModel;

import java.util.ArrayList;
import java.util.List;

public class ContactAdapter extends ArrayAdapter<ContactModel> {
    private Context mContext;
    private int mResources;
    private List<ContactModel> mlList;
    public ContactAdapter( Context context, int resource, List<ContactModel> objects) {
        super(context, resource, objects);
        this.mContext = context;
        this.mlList = objects;
        this.mResources = resource;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = null;
        if (viewHolder==null){
            convertView = LayoutInflater.from(mContext).inflate(mResources,parent,false);
            viewHolder = new ViewHolder();
            viewHolder.textViewName = convertView.findViewById(R.id.contact_tv_Name);
            viewHolder.textViewPhone = convertView.findViewById(R.id.contact_tv_Phone);
            viewHolder.btnAvatar = convertView.findViewById(R.id.contact_item_btnAvatar);
            viewHolder.btnCall = convertView.findViewById(R.id.contact_item_iv_call);
            viewHolder.ivDelete = convertView.findViewById(R.id.item_iv_delete);
            viewHolder.ivUpdate = convertView.findViewById(R.id.item_iv_update);
        }
        else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        ContactModel model = mlList.get(position);
        viewHolder.textViewName.setText(String.valueOf(model.getName()));
        viewHolder.textViewPhone.setText(String.valueOf(model.getPhoneNumber())+"  "+ String.valueOf(model.getAddress()));
        viewHolder.ivDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                remove(model);
                notifyDataSetChanged();
            }
        });
        viewHolder.ivUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(mContext,Updatechitiet.class);
                intent.putExtra("UPDATEITEM",model);
                intent.putExtra("POS",position);
                mContext.startActivity(intent);
            }
        });
        viewHolder.btnAvatar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(mContext,UserLoginDetailActivity.class);
                intent.putExtra("ContactModel",model);
                mContext.startActivity(intent);
            }
        });
        viewHolder.btnCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_DIAL);
                i.setData(Uri.parse("tel:"+ model.getPhoneNumber()));
                mContext.startActivity(i);

            }
        });

        return convertView;
    }
    public class ViewHolder {
        ImageView btnAvatar;
        ImageView btnCall;
        ImageView ivDelete;
        ImageView ivUpdate;
        TextView textViewName;
        TextView textViewPhone;


    }
}
