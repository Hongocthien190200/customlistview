package com.example.myfirstapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.myfirstapp.Model.ContactModel;

public class Updatechitiet extends AppCompatActivity {

    EditText edtName;
    EditText edtPhoneNumber;
    EditText edtAddress;
    Button btnUpdate;
    Button btnBack;
    int position = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_updatechitiet);
        onInit();
        onGetValue();
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ContactModel model = onValidateForm();
                if (model!=null) {
                    ContactActivity.modelList.add(position,model);
                    ContactActivity.adapter.notifyDataSetChanged();
                    finish();

                }
            }
        });
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
    private ContactModel onValidateForm(){
        String errorText ="Không được để trống";
        String Name = "", Phone ="", Address ="";

        int id= ContactActivity.modelList.get(ContactActivity.modelList.size()-1).getId()+1;
        Name = edtName.getText().toString();
        if (Name.length()<1){
            edtName.setError(errorText);
            return null;
        }
        Phone = edtPhoneNumber.getText().toString();
        if (Phone.length()<1){
            edtPhoneNumber.setError(errorText);
            return null;
        }
        Address = edtAddress.getText().toString();
        if (Address.length()<1){
            edtAddress.setError(errorText);
            return null;
        }
        ContactModel model = new ContactModel(id,Name,Phone,Address);
        return model;
    }

    private void onGetValue() {
        Intent intent = getIntent();
        position = intent.getIntExtra("POS",0);
        ContactModel model = (ContactModel) intent.getSerializableExtra("UPDATEITEM");
        edtName.setText(model.getName());
        edtPhoneNumber.setText((model.getPhoneNumber()));
        edtAddress.setText(model.getAddress());
    }

    private void onInit() {
        edtName = findViewById(R.id.update_edt_username);
        edtPhoneNumber = findViewById(R.id.update_edt_PhoneNumber);
        edtAddress = findViewById(R.id.update_edt_Address);
        btnUpdate = findViewById(R.id.update_btn_update);
        btnBack = findViewById(R.id.update_btn_back);
    }
}