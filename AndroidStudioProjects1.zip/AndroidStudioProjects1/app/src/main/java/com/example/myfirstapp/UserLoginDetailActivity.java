package com.example.myfirstapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.example.myfirstapp.Model.ContactModel;
import com.example.myfirstapp.Model.UserLoginDetailModel;

public class UserLoginDetailActivity extends AppCompatActivity {
    TextView tvUserName;
    TextView tvPhone;
    TextView tvAddress;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_login_detail);
        onInit();
        onGetIntent();
    }
    private void onGetIntent(){
        Intent intent = getIntent();
        ContactModel model = (ContactModel)intent.getSerializableExtra("ContactModel");
        tvUserName.setText("UserName: "+ model.getName());
        tvPhone.setText("PhoneNumber: "+ model.getPhoneNumber());
        tvAddress.setText("Address: "+ model.getAddress());
    }
    private void onInit(){
        tvUserName = findViewById(R.id.contact_tv_Name);
        tvPhone = findViewById(R.id.contact_tv_Phone);
        tvAddress = findViewById(R.id.contact_tv_Address);
    }
}